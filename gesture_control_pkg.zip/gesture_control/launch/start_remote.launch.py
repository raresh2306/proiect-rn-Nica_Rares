import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    pkg_share = get_package_share_directory('gesture_control')
    
    # Construim căile absolute din directorul de instalare ROS
    model_path = os.path.join(pkg_share, 'models', 'trained_model.pth')
    scaler_path = os.path.join(pkg_share, 'config', 'preprocessing_params.pkl')

    return LaunchDescription([
        Node(
            package='gesture_control',
            executable='remote_node',
            name='remote_gesture_controller',
            output='screen',
            parameters=[{
                'model_path': model_path,
                'scaler_path': scaler_path
            }]
        )
    ])
