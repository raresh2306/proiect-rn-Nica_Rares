import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import cv2
import mediapipe as mp
import torch
import torch.nn.functional as F
import joblib
import numpy as np
import os

# Importul modelului tau
from gesture_control.neural_network.model import GestureClassifier

class RemoteNode(Node):
    def __init__(self):
        super().__init__('remote_gesture_node')

        # --- Preluare parametri din Launch File ---
        self.declare_parameter('model_path', '')
        self.declare_parameter('scaler_path', '')
        
        model_path = self.get_parameter('model_path').get_parameter_value().string_value
        scaler_path = self.get_parameter('scaler_path').get_parameter_value().string_value

        self.get_logger().info(f"Se incarca resursele AI...")
        
        # --- Initializare AI ---
        self.ai_ready = False
        try:
            if not os.path.exists(model_path) or not os.path.exists(scaler_path):
                raise FileNotFoundError("Caile catre model sau scaler sunt invalide.")

            self.scaler = joblib.load(scaler_path)
            self.model = GestureClassifier(input_size=63, num_classes=4)
            self.model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
            self.model.eval()
            self.ai_ready = True
            self.get_logger().info("Sistem AI initializat cu succes!")
        except Exception as e:
            self.get_logger().error(f"Eroare critica AI: {e}")

        # --- Configurare MediaPipe ---
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            min_detection_confidence=0.5
        )
        self.mp_draw = mp.solutions.drawing_utils

        # --- Configurare ROS ---
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Timer pentru procesare (30 FPS)
        self.timer = self.create_timer(1.0/30.0, self.process_loop)
        
        # --- Configurare Camera (FIX PENTRU WSL) ---
        # Incearca index 0. Daca nu merge, schimba cu 2 sau 1.
        self.cap = cv2.VideoCapture(0)
        
        # Setari fortate pentru MJPEG si rezolutie mica (evita timeout in WSL)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        
        if not self.cap.isOpened():
            self.get_logger().error("Nu pot deschide camera web locala!")

        # Mapari
        self.labels_map = {0: 'STOP', 1: 'INAINTE', 2: 'STANGA', 3: 'DREAPTA'}
        self.threshold_stop = 0.60
        self.threshold_move = 0.85

    def process_loop(self):
        if not self.ai_ready:
            return

        ret, frame = self.cap.read()
        if not ret:
            # Daca nu citeste cadrul, nu crapa, doar ignora
            return

        # Oglindire si procesare
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)
        
        command = "STOP"
        prob = 0.0
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                self.mp_draw.draw_landmarks(frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)
                
                # Extragere date
                landmarks_data = []
                for lm in hand_landmarks.landmark:
                    landmarks_data.extend([lm.x, lm.y, lm.z])
                
                # Inferenta
                input_data = np.array([landmarks_data], dtype=np.float32)
                input_scaled = self.scaler.transform(input_data)
                input_tensor = torch.tensor(input_scaled)

                with torch.no_grad():
                    outputs = self.model(input_tensor)
                    probs = F.softmax(outputs, dim=1)
                
                probabilities = probs.numpy()[0]
                predicted_idx = np.argmax(probabilities)
                max_prob = probabilities[predicted_idx]
                
                # Decizie praguri
                required_threshold = self.threshold_stop if predicted_idx == 0 else self.threshold_move

                if max_prob > required_threshold:
                    command = self.labels_map[predicted_idx]
                    prob = max_prob
                else:
                    command = "NESIGUR"

        # Publicare Comanda ROS
        self.publish_command(command)

        # Vizualizare Locala
        color = (0, 255, 0) if command not in ["STOP", "NESIGUR"] else (0, 0, 255)
        cv2.putText(frame, f"CMD: {command} ({prob:.2f})", (10, 50), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        
        cv2.imshow("Control Robot - Laptop Local", frame)
        cv2.waitKey(1)

    def publish_command(self, command):
        msg = Twist()
        SPEED_LIN = 0.2
        SPEED_ANG = 0.5

        if command == 'INAINTE':
            msg.linear.x = SPEED_LIN
        elif command == 'STANGA':
            msg.angular.z = SPEED_ANG
        elif command == 'DREAPTA':
            msg.angular.z = -SPEED_ANG
        
        self.cmd_vel_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = RemoteNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cap.release()
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()
