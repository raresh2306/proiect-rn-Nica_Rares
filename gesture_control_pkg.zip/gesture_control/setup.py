from setuptools import setup
import os
from glob import glob

package_name = 'gesture_control'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name, f'{package_name}.neural_network'], # Include folderul neural_network
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Instalăm fișierele de lansare
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        # Instalăm resursele (model + config)
        (os.path.join('share', package_name, 'models'), glob('models/*.pth')),
        (os.path.join('share', package_name, 'config'), glob('config/*.pkl')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='student',
    maintainer_email='student@todo.todo',
    description='Pachet control gesturi remote',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'remote_node = gesture_control.remote_node:main',
        ],
    },
)
